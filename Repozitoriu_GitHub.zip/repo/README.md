# Laborator GitHub

Repozitoriu creat pentru lucrarea practică la versionare (Git / GitHub).

Fișiere:
- index.html – pagina principală
- style.css – stiluri
